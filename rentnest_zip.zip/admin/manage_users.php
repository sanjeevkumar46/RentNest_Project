<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";
include "../includes/header.php";
include "../includes/navbar.php";

$sql = "SELECT * FROM users ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<section class="rooms-section">

    <h2>Manage Users</h2>

    <table border="1" width="100%" cellpadding="10" cellspacing="0">

        <tr>

            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Role</th>
            <th>Status</th>
            <th>Action</th>

        </tr>

        <?php while($row = mysqli_fetch_assoc($result)){ ?>

        <tr>

            <td><?php echo $row['id']; ?></td>

            <td><?php echo $row['fullname']; ?></td>

            <td><?php echo $row['email']; ?></td>

            <td><?php echo $row['phone']; ?></td>

            <td><?php echo ucfirst($row['role']); ?></td>

            <td>

              <?php

              if($row['status'] == "active")
              {
                echo "<span style='color:#16a34a;font-weight:bold;'>🟢 Active</span>";
              }
              elseif($row['status'] == "blocked")
              { 
                echo "<span style='color:#dc2626;font-weight:bold;'>🔴 Blocked</span>";
              }
              else
              {
                echo ucfirst($row['status']);
              }

              ?>

            </td>
            <td>

<?php if($row['id'] != $_SESSION['user_id']) { ?>

    <a href="delete_user.php?id=<?php echo $row['id']; ?>"
       onclick="return confirm('Delete this user?')">

        <button style="background:#dc2626;">
            🗑️ Delete
        </button>

    </a>

<?php } else { ?>

    <span style="color:#16a34a;font-weight:bold;">
        Current Admin
    </span>

<?php } ?>

</td>

        </tr>

        <?php } ?>

    </table>

</section>

<?php include "../includes/footer.php"; ?>