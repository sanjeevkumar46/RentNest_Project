<?php
session_start();

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != "admin")
{
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";
include "../includes/header.php";
include "../includes/navbar.php";

$sql = "SELECT
            bookings.id,
            bookings.booking_date,
            bookings.status,
            users.fullname,
            users.phone,
            rooms.title,
            rooms.city,
            rooms.owner_id,
            owner.fullname AS owner_name,
            owner.phone AS owner_phone
        FROM bookings
        JOIN users ON bookings.user_id = users.id
        JOIN rooms ON bookings.room_id = rooms.id
        JOIN users AS owner ON rooms.owner_id = owner.id
        ORDER BY bookings.id DESC";

$result = mysqli_query($conn, $sql);
?>

<section class="dashboard-section">

<h2>Manage Bookings</h2>

<table border="1" width="100%" cellpadding="10" cellspacing="0">

<tr>
    <th>ID</th>
    <th>User</th>
    <th>Phone</th>
    <th>Room</th>
    <th>City</th>
    <th>Owner</th>
    <th>Owner Phone</th>
    <th>Booking Date</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)) { ?>

<tr>

    <td>
        <?php echo $row['id']; ?>
    </td>

    <td>
        <?php echo $row['fullname']; ?>
    </td>

    <td>
        <?php echo $row['phone']; ?>
    </td>

    <td>
        <?php echo $row['title']; ?>
    </td>

    <td>
        <?php echo $row['city']; ?>
    </td>

    <td>
    <?php echo $row['owner_name']; ?>
    </td>

    <td>
    <?php echo $row['owner_phone']; ?>
    </td>

    <td>
        <?php echo $row['booking_date']; ?>
    </td>

    <td>

        <?php

        if($row['status'] == "Pending")
        {
            echo "<span style='color:#f59e0b;font-weight:bold;'>Pending</span>";
        }
        elseif($row['status'] == "Approved")
        {
            echo "<span style='color:#16a34a;font-weight:bold;'>Approved</span>";
        }
        elseif($row['status'] == "Rejected")
        {
            echo "<span style='color:#dc2626;font-weight:bold;'>Rejected</span>";
        }
        elseif($row['status'] == "Cancelled")
        {
            echo "<span style='color:#6b7280;font-weight:bold;'>Cancelled</span>";
        }

        ?>

    </td>

    <td>

        <?php if($row['status'] == "Pending") { ?>

            <a href="update_booking.php?id=<?php echo $row['id']; ?>&status=Approved">
                <button style="background:green;">
                    Approve
                </button>
            </a>

            <a href="update_booking.php?id=<?php echo $row['id']; ?>&status=Rejected">
                <button style="background:red;">
                    Reject
                </button>
            </a>

        <?php } else { ?>

            <span>No Action</span>

        <?php } ?>

    </td>

</tr>

<?php } ?>

</table>

</section>

<?php include "../includes/footer.php"; ?>