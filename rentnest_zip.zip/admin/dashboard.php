<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";
include "../includes/header.php";
include "../includes/navbar.php";


// ===============================
// COUNT USERS
// ===============================

$user_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE role='user'"
);

$user_count = mysqli_fetch_assoc($user_query);


// ===============================
// COUNT OWNERS
// ===============================

$owner_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM users
     WHERE role='owner'"
);

$owner_count = mysqli_fetch_assoc($owner_query);


// ===============================
// COUNT ROOMS
// ===============================

$room_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM rooms"
);

$room_count = mysqli_fetch_assoc($room_query);


// ===============================
// COUNT ALL BOOKINGS
// ===============================

$booking_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings"
);

$booking_count = mysqli_fetch_assoc($booking_query);


// ===============================
// COUNT PENDING BOOKINGS
// ===============================

$pending_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings
     WHERE status='Pending'"
);

$pending_count = mysqli_fetch_assoc($pending_query);


// ===============================
// COUNT APPROVED BOOKINGS
// ===============================

$approved_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings
     WHERE status='Approved'"
);

$approved_count = mysqli_fetch_assoc($approved_query);


// ===============================
// COUNT CANCELLED BOOKINGS
// ===============================

$cancelled_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM bookings
     WHERE status='Cancelled'"
);

$cancelled_count = mysqli_fetch_assoc($cancelled_query);

?>

<section class="dashboard-section">

    <h2>Admin Dashboard</h2>


    <!-- =========================
         DASHBOARD CARDS
    ========================== -->

    <div class="dashboard-container">


        <!-- USERS -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Total Users
            </h3>

            <h1 style="
                color:#2563eb !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $user_count['total']; ?>
            </h1>

        </div>


        <!-- OWNERS -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Total Owners
            </h3>

            <h1 style="
                color:#7c3aed !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $owner_count['total']; ?>
            </h1>

        </div>


        <!-- ROOMS -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Total Rooms
            </h3>

            <h1 style="
                color:#0891b2 !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $room_count['total']; ?>
            </h1>

        </div>


        <!-- TOTAL BOOKINGS -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Total Bookings
            </h3>

            <h1 style="
                color:#2563eb !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $booking_count['total']; ?>
            </h1>

        </div>


        <!-- PENDING -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Pending
            </h3>

            <h1 style="
                color:#f59e0b !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $pending_count['total']; ?>
            </h1>

        </div>


        <!-- APPROVED -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Approved
            </h3>

            <h1 style="
                color:#16a34a !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $approved_count['total']; ?>
            </h1>

        </div>


        <!-- CANCELLED -->

        <div class="dashboard-card">

            <h3 style="color:#333;">
                Cancelled
            </h3>

            <h1 style="
                color:#dc2626 !important;
                font-size:48px;
                font-weight:bold;
                margin:10px 0;
            ">
                <?php echo $cancelled_count['total']; ?>
            </h1>

        </div>

    </div>


    <!-- =========================
         ADMIN ACTION BUTTONS
    ========================== -->

    <div
        class="dashboard-container"
        style="margin-top:40px;"
    >

        <a href="manage_users.php">
            <button>
                Manage Users
            </button>
        </a>


        <a href="manage_rooms.php">
            <button>
                Manage Rooms
            </button>
        </a>


        <a href="manage_bookings.php">
            <button>
                Manage Bookings
            </button>
        </a>
        <a href="manage_messages.php">
    <button>
        📩 Manage Messages
    </button>
</a>

    </div>

</section>


<?php include "../includes/footer.php"; ?>