<?php
include "../config/db.php";

$id = $_GET['id'];

$sql = "UPDATE bookings
        SET status='Rejected'
        WHERE id='$id'";

mysqli_query($conn, $sql);

header("Location: manage_bookings.php");
exit();
?>