<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";
include "../includes/header.php";
include "../includes/navbar.php";

$sql = "SELECT * FROM rooms ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<section class="rooms-section">

    <h2>Manage Rooms</h2>

    <table border="1" width="100%" cellpadding="10" cellspacing="0">

        <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Title</th>
            <th>City</th>
            <th>Rent</th>
            <th>Owner ID</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <tr>

            <td><?php echo $row['id']; ?></td>

            <td>
                <img src="../uploads/<?php echo $row['image']; ?>"
                     width="100">
            </td>

            <td><?php echo $row['title']; ?></td>

            <td><?php echo $row['city']; ?></td>

            <td>₹<?php echo $row['rent']; ?></td>

            <td><?php echo $row['owner_id']; ?></td>

<td>

<?php
            
if($row['status'] == "available")
{
    echo "<b style='color:#16a34a;'>Available</b>";
}
elseif($row['status'] == "booked")
{
    echo "<b style='color:#dc2626;'>Booked</b>";
}
else
{
    echo "<b>".$row['status']."</b>";
}

?>

</td>

            <td>

                <a href="delete_room.php?id=<?php echo $row['id']; ?>"
                   onclick="return confirm('Delete this room?')">

                    <button>Delete</button>

                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

</section>

<?php include "../includes/footer.php"; ?>