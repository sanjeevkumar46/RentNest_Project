<?php
session_start();

if(!isset($_SESSION['user_id']))
{
    header("Location: ../login.php");
    exit();
}

if($_SESSION['role'] != "admin")
{
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";
include "../includes/header.php";
include "../includes/navbar.php";

$sql = "SELECT * FROM contact_messages ORDER BY id DESC";

$result = mysqli_query($conn, $sql);
?>

<section class="dashboard-section">

    <h2>Contact Messages</h2>

    <table border="1" width="100%" cellpadding="10" cellspacing="0">

        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Subject</th>
            <th>Message</th>
            <th>Date</th>
        </tr>

        <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <tr>

            <td>
                <?php echo $row['id']; ?>
            </td>

            <td>
                <?php echo $row['fullname']; ?>
            </td>

            <td>
                <?php echo $row['email']; ?>
            </td>

            <td>
                <?php echo $row['subject']; ?>
            </td>

            <td>
                <?php echo $row['message']; ?>
            </td>

            <td>
                <?php echo $row['created_at']; ?>
            </td>

        </tr>

        <?php } ?>

    </table>

</section>

<?php
include "../includes/footer.php";
?>