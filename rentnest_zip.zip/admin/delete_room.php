<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

include "../config/db.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM rooms WHERE id='$id'");

header("Location: manage_rooms.php");
exit();
?>